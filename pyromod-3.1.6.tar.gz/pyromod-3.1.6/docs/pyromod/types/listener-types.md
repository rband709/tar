### *enum* pyromod.types.ListenerTypes

The `pyromod.types.ListenerTypes` enum defines the various types of listeners that you can use in pyromod.

### *Member Values:*

- **MESSAGE** ("message")

- **CALLBACK_QUERY** ("callback_query")
